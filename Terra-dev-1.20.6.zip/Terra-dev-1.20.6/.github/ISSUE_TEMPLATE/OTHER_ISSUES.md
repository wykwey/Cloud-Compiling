---
name: "Other Issue"
about: "Use this template if your issue doesn't accurately fit into any of the
other categories."
title: ""
labels: "Type: Question, Status: Pending"
assignees: ""

---

## Describe the issue

<!-- Please describe the issue as clearly and as concisely as possible, without missing any details. -->