# biome-provider-pipeline

Implements the Biome Pipeline, a procedural biome provider that uses a series
of "stages" to apply "mutations" to a 2D grid of biomes.

This addon registers the `PIPELINE` biome provider type, and all associated
configurations.