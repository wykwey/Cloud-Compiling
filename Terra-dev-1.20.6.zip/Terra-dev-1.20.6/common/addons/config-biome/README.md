# config-biome

Registers the default configuration for Terra Biomes, `BIOME`.