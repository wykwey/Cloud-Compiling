# Core Addons

This directory contains the modularized "core addons" that implement Terra's
default behavior.