# config-flora

Registers the default configuration for Terra Flora, `FLORA`.