# biome-provider-single

Registers and configures the `SINGLE` biome provider, a biome provider which
accepts a single biome to generate continuously.