# chunk-generator-noise-3d

Registers the `NOISE_3D` chunk generator, a chunk generator which uses biomes'
samplers in 3D to generate chunk data.