version = version("1.0.1")

dependencies {
    compileOnlyApi(project(":common:addons:manifest-addon-loader"))
}