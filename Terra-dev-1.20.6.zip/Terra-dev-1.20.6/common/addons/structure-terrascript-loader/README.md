# structure-terrascript-loader

Implements the TerraScript structure scripting language, and loads all `*.tesf`
files into the Structure registry.