# biome-provider-image

Implements and registers the `IMAGE` biome provider, a biome provider which
generates biomes from an image, using the `color` attribute of biomes.

This addon registers the provider type, and all associated config options.