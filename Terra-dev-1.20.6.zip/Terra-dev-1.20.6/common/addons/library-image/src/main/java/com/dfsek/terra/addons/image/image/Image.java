package com.dfsek.terra.addons.image.image;

public interface Image {
    int getRGB(int x, int y);

    int getWidth();

    int getHeight();
}
