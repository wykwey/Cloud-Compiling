package com.dfsek.terra.addons.image.config.converter;

import com.dfsek.tectonic.api.config.template.object.ObjectTemplate;

import com.dfsek.terra.addons.image.converter.ColorConverter;


public interface ColorConverterTemplate<T> extends ObjectTemplate<ColorConverter<T>> {
}
