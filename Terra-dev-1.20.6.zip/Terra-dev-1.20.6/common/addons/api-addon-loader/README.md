# api addon loader

Loads dependencies as addons