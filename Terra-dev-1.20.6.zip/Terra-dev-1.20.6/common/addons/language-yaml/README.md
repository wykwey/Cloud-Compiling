# language-yaml

Allows `*.yml` files to be loaded as Terra configurations.