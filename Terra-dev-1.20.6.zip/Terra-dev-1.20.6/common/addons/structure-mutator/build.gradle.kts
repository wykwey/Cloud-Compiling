version = version("0.1.0")

dependencies {
    compileOnlyApi(project(":common:addons:manifest-addon-loader"))
}
