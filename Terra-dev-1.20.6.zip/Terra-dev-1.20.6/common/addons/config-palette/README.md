# config-palette

Registers the default configuration for Terra Palettes, `PALETTE`.