# config-ore

Registers the default configuration for Terra Ores, `ORE`.