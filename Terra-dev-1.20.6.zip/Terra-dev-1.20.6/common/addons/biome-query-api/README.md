# Biome Query API

This addon contains an API to allow other addons to quickly query
Biome data, by baking queries and using Contexts on biomes.