# config-noise-function

Registers the default noise functions.