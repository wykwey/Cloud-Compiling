# config-structure

Registers the default configuration for Terra Structures, `STRUCTURE`.