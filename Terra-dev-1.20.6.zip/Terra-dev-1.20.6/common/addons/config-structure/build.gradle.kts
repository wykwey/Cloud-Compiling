version = version("1.0.1")

dependencies {
    api("com.googlecode.json-simple:json-simple:1.1.1")
    compileOnlyApi(project(":common:addons:manifest-addon-loader"))
}
